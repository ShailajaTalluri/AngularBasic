﻿using Admin.Context;
using Admin.ExceptionHandler;
using Admin.Models;
using Admin.Services;
using Adminproject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Repositories
{
    public class AdminRepo:IAdminRepo
    {
        readonly AdminContext _adminContext;
        private object _adminService;

        public AdminRepo(AdminContext adminContext)
        {
            _adminContext = adminContext;
        }

        public int AddAdmin(AdminRegister admin)
        {
            
            _adminContext.AdminTbl.Add(admin);
            return _adminContext.SaveChanges();
        }

        public AdminRegister GetAdminByEmail(string email)
        {
            
          return  _adminContext.AdminTbl.Where(s => s.Email == email).FirstOrDefault();
            
        }

        public string logIn(Login alogin)
        {
            AdminRegister login = _adminContext.AdminTbl.Where(a => a.Name == alogin.Name && a.Password == alogin.Password).FirstOrDefault();
            if (login != null)
            {
                return "sucessful";
            }
            else
            {
                throw new InvalidPasswordException($"Invalid Password");
            }
            //return alogin;
            //if (login != null)
            //{
            //    if (login.Password == login.Password)
            //    {
            //        return "sucess";
            //    }
            //    else
            //    {
            //        throw new InvalidPasswordException($"Invalid Password");
            //    }
            ////}
            //else
            //{
            //    throw new StaffInvalidException($"Invalid Credentials");
            //}
        }
    }

}


