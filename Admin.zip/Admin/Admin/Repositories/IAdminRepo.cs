﻿using Admin.Models;
using Adminproject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Repositories
{
    public interface IAdminRepo
    {
        int AddAdmin(AdminRegister admin);
        string logIn(Login login);
        AdminRegister GetAdminByEmail(string email);
        //string GetAdminByEmail(string email);
    }
}
