﻿//using Adminproject.Models.Adminlogin.Model;
using Adminproject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Context
{
    public class AdminContext : DbContext
    {
        public AdminContext(DbContextOptions<AdminContext> Context) : base(Context)
        {

        }
        public DbSet<AdminRegister> AdminTbl { get; set; }

    }
}
