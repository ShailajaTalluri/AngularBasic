﻿using Admin.Models;
using Adminproject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Services
{
    public interface IAdminService
    {
        //object AddAdmin(Admin admin);
        //object AddAdmin(login admin);
        
        string Login(Login login);
        string AddAdmin(AdminRegister admin);
    }
}
