﻿using Admin.Models;
using Admin.Repositories;
using Adminproject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Services
{
    public class AdminService : IAdminService
    {
        readonly IAdminRepo _adminRepo;
        public AdminService(IAdminRepo adminRepo)
        {
            _adminRepo = adminRepo;
        }
        public string AddAdmin(AdminRegister admin)
        {
            
            AdminRegister adminExists = _adminRepo.GetAdminByEmail(admin.Email);
            if (adminExists == null)
            {
                int a = _adminRepo.AddAdmin(admin);
                if (a == 1)
                {
                    return $"added successfully";
                }
                else
                {
                    return $"unsuccessful";
                }
            }
            else
            {
                return $"unsuccessful";
            }
        }

        public string Login(Login login)
        {
            string admin = _adminRepo.logIn(login);
            return admin;
        }
    }
}
