﻿using Admin.Models;
using Admin.Services;
using Admin.SRP;
using Adminproject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Controllers
{
    [ExceptionHandler]
    [Route("api/[controller]")]
    [ApiController]
    
    public class AdminController : ControllerBase
    {
        readonly IAdminService _adminService;
        public AdminController(IAdminService adminService)
        {
            this._adminService = adminService;
        }
        [Route("AddAdmin")]
        [HttpPost]
        public ActionResult AddAdmin(AdminRegister admin)
        {
            string status = _adminService.AddAdmin(admin);
            return Ok(status);
        }

        [Route("login")]
        [HttpPost]
        public ActionResult LogIn(Login login)
        {
            string admin = _adminService.Login(login);
            return Ok(admin);
        }
    }
}
