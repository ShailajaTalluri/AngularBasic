import React from "react";
import { Box, Button, Grid, TextField, Typography } from '@mui/material'
import { deepOrange, deepPurple } from '@mui/material/colors'

import axios from 'axios';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';



const AdminLogin = () => {
    
    const [Name, setName]=useState("");
    const [Password, setPassword]=useState("");

    const handleApi = () => {
        console.log({Name, Password})
        axios.post('http://localhost:19442/api/Admin/login',{
            Name : Name,
            Password : Password
        })
        .then(result => {
            console.log(result)
            alert("Login Successful...");
         
        })
        .catch(error => {
            console.log(error)
            alert("Invalid Password");
        })
    }
  return (
    <div>
        <h1>
             AdminLogin
        </h1>
        <Grid container>
        <form noValidate>
         <Grid container spacing={1}>
            
            <Grid item xs={12} sm={12}>
                <TextField  type="name" autoComplete='off' name='Name' fullWidth id="Name" variant='outlined' label="Name" autoFocus
                onChange={(e)=>setName(e.target.value)} />
            </Grid>

            <Grid item xs={12} sm={12}>
                <TextField type="password" autoComplete='off' name='Password' fullWidth id="Password" variant='outlined' label="Password" autoFocus
                onChange={(e)=>setPassword(e.target.value)}/>
            </Grid>
            <Grid item xs={12} sm={12}>
            <Button type='button' variant='contained' onClick={handleApi}>Login</Button>
            </Grid>
         </Grid>
         </form>
        </Grid>
        
    </div>
  )
}

export default AdminLogin



